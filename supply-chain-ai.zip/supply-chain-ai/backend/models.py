class Supplier:
    def __init__(self, sid, tier, inventory, prod_rate, uptime, labor, delay, deps):
        self.sid = sid
        self.tier = tier
        self.reported_inventory = inventory
        self.production_rate = prod_rate
        self.machine_uptime = uptime
        self.labor_availability = labor
        self.transport_delay = delay
        self.dependencies = deps
        self.expected_inventory = 0
        self.phantom_index = 0
        self.risk_score = 0

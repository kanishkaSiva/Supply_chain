from fastapi import FastAPI
import pandas as pd
from backend.models import Supplier
from agents.supply_agent import SupplyAgent
from agents.validation_agent import ValidationAgent
from agents.prediction_agent import PredictionAgent
from agents.risk_agent import RiskAgent
from simulation.disruption_events import apply_disruptions

app = FastAPI()

@app.get("/run")
def run_simulation():
    df = pd.read_csv("data/suppliers.csv")
    suppliers = []

    for _, r in df.iterrows():
        s = Supplier(
            r.sid, r.tier, r.inventory, r.prod_rate,
            r.uptime, r.labor, r.delay, eval(r.deps)
        )
        s = apply_disruptions(s)
        s = SupplyAgent().update_expected_inventory(s)
        s = ValidationAgent().detect_phantom_stock(s)
        s = PredictionAgent().predict_failure_risk(s)
        suppliers.append(s)

    alerts = RiskAgent().propagate_risk(suppliers)

    return {
        "suppliers": [
            {
                "id": s.sid,
                "tier": s.tier,
                "reported": s.reported_inventory,
                "expected": round(s.expected_inventory, 2),
                "phantom_index": round(s.phantom_index, 2),
                "risk_score": round(s.risk_score, 2)
            } for s in suppliers
        ],
        "alerts": alerts
    }

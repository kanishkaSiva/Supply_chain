import streamlit as st
import requests

st.set_page_config(layout="wide")
st.title("Multi-Tier Phantom Stock Intelligence System")

data = requests.get("http://localhost:8000/run").json()

st.subheader("Supplier Health")
st.table(data["suppliers"])

st.subheader("🚨 Early Risk Alerts")
for a in data["alerts"]:
    st.error(f"{a['path']} | Impact in {a['impact_days']} days | Confidence {a['confidence']}%")

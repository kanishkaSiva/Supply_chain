import pandas as pd
import random
import os

os.makedirs("data", exist_ok=True)

def generate_large_supply_chain(
    tier1_count=2,
    tier2_per_tier1=3,
    tier3_per_tier2=4
):
    rows = []

    tier1_ids = [f"T1_{i}" for i in range(tier1_count)]
    tier2_ids = []
    tier3_ids = []

    # ---------- Tier 3 (Raw suppliers) ----------
    for t1 in tier1_ids:
        for i in range(tier2_per_tier1):
            t2_id = f"T2_{t1}_{i}"
            tier2_ids.append((t2_id, t1))

            for j in range(tier3_per_tier2):
                t3_id = f"T3_{t2_id}_{j}"
                tier3_ids.append((t3_id, t2_id))

                rows.append([
                    t3_id,
                    3,
                    random.randint(300, 800),
                    random.randint(30, 60),
                    round(random.uniform(0.7, 0.95), 2),
                    round(random.uniform(0.7, 0.95), 2),
                    round(random.uniform(0.05, 0.25), 2),
                    []
                ])

    # ---------- Tier 2 (Processors) ----------
    for t2_id, t1 in tier2_ids:
        deps = [t3 for t3, parent in tier3_ids if parent == t2_id]
        rows.append([
            t2_id,
            2,
            random.randint(600, 1200),
            random.randint(60, 100),
            round(random.uniform(0.75, 0.95), 2),
            round(random.uniform(0.75, 0.95), 2),
            round(random.uniform(0.05, 0.2), 2),
            deps
        ])

    # ---------- Tier 1 (Manufacturers) ----------
    for t1 in tier1_ids:
        deps = [t2 for t2, parent in tier2_ids if parent == t1]
        rows.append([
            t1,
            1,
            random.randint(1000, 2000),
            random.randint(90, 140),
            round(random.uniform(0.85, 0.98), 2),
            round(random.uniform(0.85, 0.98), 2),
            round(random.uniform(0.03, 0.15), 2),
            deps
        ])

    df = pd.DataFrame(
        rows,
        columns=[
            "sid",
            "tier",
            "inventory",
            "prod_rate",
            "uptime",
            "labor",
            "delay",
            "deps"
        ]
    )

    df.to_csv("data/suppliers.csv", index=False)
    print(f"Generated supply chain with {len(df)} suppliers")

if __name__ == "__main__":
    generate_large_supply_chain(
        tier1_count=2,
        tier2_per_tier1=3,
        tier3_per_tier2=4
    )

import random

def apply_disruptions(supplier):
    if random.random() < 0.15:
        supplier.machine_uptime *= 0.6
    if random.random() < 0.1:
        supplier.labor_availability *= 0.7
    if random.random() < 0.1:
        supplier.transport_delay += 0.2
    return supplier


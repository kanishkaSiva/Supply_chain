class RiskAgent:
    def propagate_risk(self, suppliers):
        alerts = []
        for s in suppliers:
            if s.risk_score > 0.6:
                for parent in suppliers:
                    if s.sid in parent.dependencies:
                        alerts.append({
                            "path": f"{s.sid} → {parent.sid}",
                            "impact_days": 3 + s.tier,
                            "confidence": round(s.risk_score * 100, 2)
                        })
        return alerts

import random

class PredictionAgent:
    def predict_failure_risk(self, supplier):
        base_risk = (
            (1 - supplier.machine_uptime) +
            (1 - supplier.labor_availability) +
            supplier.transport_delay
        )
        supplier.risk_score = min(1.0, base_risk + random.uniform(0, 0.2))
        return supplier

class ValidationAgent:
    def detect_phantom_stock(self, supplier):
        if supplier.reported_inventory == 0:
            supplier.phantom_index = 0
        else:
            supplier.phantom_index = (
                (supplier.reported_inventory - supplier.expected_inventory)
                / supplier.reported_inventory
            )
        return supplier
